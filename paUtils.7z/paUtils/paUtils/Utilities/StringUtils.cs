using System;
using System.Text;

namespace Kbg.NppPluginNET.Utilities
{
    public static class StringUtils
    {
        /// <summary>
        /// Converts and ANSI string to Unicode.
        /// </summary>
        public static string AnsiToUnicode(string str)
        {
            var text = Encoding.UTF8.GetString(Encoding.Default.GetBytes(str));
            return text;
        }

        /// <summary>
        /// Converts a Unicode string to ANSI
        /// </summary>
        public static string UnicodeToAnsi(string str)
        {
            var text = Encoding.Default.GetString(Encoding.UTF8.GetBytes(str));
            return text;
        }
    }
}