﻿using Kbg.NppPluginNET.PluginInfrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kbg.NppPluginNET.Utilities;

namespace Kbg.NppPluginNET.PluginInfrastructure
{
    internal class Editor : PluginBase
    {
        private readonly IntPtr _activeScintilla;
        private Editor(IntPtr activeScintilla)
        {
            _activeScintilla = activeScintilla;
        }

        public static Editor GetActive()
        {
            return new Editor(GetCurrentScintilla());
        }

        public int GetSelectionLength()
        {
            return Call(SciMsg.SCI_GETSELTEXT);
        }

        public string GetSelectedText()
        {
            var selLength = GetSelectionLength();
            // Todo: Use a string / char array as stringbuilder can't handle null characters?
            var selectedText = new StringBuilder(selLength);
            if (selLength > 0)
                Call(SciMsg.SCI_GETSELTEXT, 0, selectedText);
            var ret = selectedText.ToString();
            return IsUnicode() ? StringUtils.UnicodeToAnsi(ret) : ret;
        }

        public string GetSelectedOrAllText()
        {
            var selectedText = GetSelectedText();
            return string.IsNullOrEmpty(selectedText) ? GetDocumentText() : selectedText;
        }

        public bool IsUnicode()
        {
            var result = Call(SciMsg.SCI_GETCODEPAGE);
            return result == (int)SciMsg.SC_CP_UTF8;
        }

        public string GetDocumentText()
        {
            var length = GetDocumentLength();
            var text = new StringBuilder(length + 1);
            if (length > 0)
                Call(SciMsg.SCI_GETTEXT, length + 1, text);
            var ret = text.ToString();
            return IsUnicode() ? StringUtils.UnicodeToAnsi(ret) : ret;
        }

        public void SetSelectedText(string text)
        {
            if (IsUnicode())
                text = StringUtils.UnicodeToAnsi(text);
            Call(SciMsg.SCI_REPLACESEL, 0, text);
        }

        /// <summary>
        /// Sets the text for the entire document (replacing any existing text).
        /// </summary>
        /// <param name="text">The document text to set.</param>
        public void SetDocumentText(string text)
        {
            if (IsUnicode())
                text = StringUtils.UnicodeToAnsi(text);
            Call(SciMsg.SCI_SETTEXT, 0, text);
        }

        public int GetDocumentLength()
        {
            return Call(SciMsg.SCI_GETLENGTH);
        }

        #region Private Call Methods

        private int Call(SciMsg msg, int wParam, IntPtr lParam)
        {
            return (int)Win32.SendMessage(_activeScintilla, msg, wParam, lParam);
        }

        private int Call(SciMsg msg, int wParam, string lParam)
        {
            return (int)Win32.SendMessage(_activeScintilla, msg, wParam, lParam);
        }

        private int Call(SciMsg msg, int wParam, StringBuilder lParam)
        {
            return (int)Win32.SendMessage(_activeScintilla, msg, wParam, lParam);
        }

        private int Call(SciMsg msg, int wParam, int lParam)
        {
            return (int)Win32.SendMessage(_activeScintilla, msg, wParam, lParam);
        }

        private int Call(SciMsg msg, int wParam)
        {
            return Call(msg, wParam, 0);
        }

        private int Call(SciMsg msg)
        {
            return Call(msg, 0, 0);
        }

        #endregion

    }
}
