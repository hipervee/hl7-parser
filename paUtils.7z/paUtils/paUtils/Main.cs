﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Kbg.NppPluginNET.PluginInfrastructure;

namespace Kbg.NppPluginNET
{
    class Main
    {
        internal const string PluginName = "PA Utils";
        internal static bool isSelected = false;
        public static void OnNotification(ScNotification notification)
        {
        }

        internal static void CommandMenuInit()
        {
            PluginBase.SetCommand(0, "Format HL7", FormatHL7, new ShortcutKey(true, true, false, Keys.H));
        }

        internal static void FormatHL7()
        {
            var segmentIds = new List<string>() { "ABS", "ACC", "ADD", "AFF", "AIG", "AIL", "AIP", "AIS", "AL1", "APR", "ARQ", "AUT", "BLC", "BLG", "BPO", "BPX", "BTX", "CDM", "CER", "CM0", "CM1", "CM2", "CNS", "CSP", "CSR", "CSS", "CTD", "CTI", "DB1", "DG1", "DRG", "DSC", "DSP", "ECD", "ECR", "EDU", "EQL", "EQP", "EQU", "ERQ", "ERR", "EVN", "FAC", "FT1", "GOL", "GP1", "GP2", "GT1", "IAM", "IIM", "IN1", "IN2", "IN3", "INV", "IPC", "ISD", "LAN", "LCC", "LCH", "LDP", "LOC", "LRL", "MFA", "MFE", "MFI", "MRG", "MSA", "NCK", "NDS", "NK1", "NPU", "NSC", "NST", "NTE", "OBR", "OBX", "ODS", "ODT", "OM1", "OM2", "OM3", "OM4", "OM5", "OM6", "OM7", "ORC", "ORG", "OVR", "PCR", "PD1", "PDA", "PDC", "PEO", "PES", "PID", "PR1", "PRA", "PRB", "PRC", "PRD", "PSH", "PTH", "PV1", "PV2", "QAK", "QID", "QPD", "QRD", "QRF", "QRI", "RCP", "RDF", "RDT", "RF1", "RGS", "RMI", "ROL", "RQ1", "RQD", "RXA", "RXC", "RXD", "RXE", "RXG", "RXO", "RXR", "SAC", "SCH", "SFT", "SID", "SPM", "SPR", "STF", "TCC", "TCD", "TQ1", "TQ2", "TXA", "UB1", "UB2", "URD", "URS", "VAR" };
            var gatewayFactory = PluginBase.GetGatewayFactory();
            var gateway = gatewayFactory();
            var text = GetText(gateway);
            text = text.Replace(Environment.NewLine, "").Replace("\r", "").Replace("\n", "");
            segmentIds.ForEach(o =>
                {
                    var segment = o + "|";
                    text = text.Replace(segment, Environment.NewLine + segment);
                });
            if (isSelected)
            {
                gateway.ReplaceSel(text);
            }
            else
            {
                gateway.SetText(text);
            }           
        }

        internal static void SetToolBarIcon()
        {

        }

        internal static string GetText(IScintillaGateway gateway)
        {
            var textLength = gateway.GetTextLength();
            var text = gateway.GetSelText();
            isSelected = !string.IsNullOrEmpty(text);
            if(!isSelected)
            {
                text = gateway.GetText(textLength);
            }
            return text;
        }

        internal static void PluginCleanUp()
        {
        }
    }
}